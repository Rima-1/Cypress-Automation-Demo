import {Given,When,Then, And } from "cypress-cucumber-preprocessor/steps";

import HomePage from '../../../../support/Page-Objects/HomePage'
import ShopPage from '../../../../support/Page-Objects/ShopPage'
import CheckoutPage from '../../../../support/Page-Objects/CheckoutPage'
import PurchasePage from '../../../../support/Page-Objects/PurchasePage'

    const homePage=new HomePage()
    const shopPage=new ShopPage()
    const checkoutPage=new CheckoutPage()
    const purchasePage=new PurchasePage()
    let name 

Given('I open Ecommerce Page', ()=>
{
    cy.visit(Cypress.env('url'))

})

When('I add items to Cart', function()
{
    homePage.getShopTab().click()
    const phoneListLocator=this.data.phoneArrayLocator
    this.data.phonenames.forEach(function(element) 
    {
        cy.selectProductFromList(element, phoneListLocator)
    })
    shopPage.getCheckoutButton().click()
})

And('Validate the total prices', function()
{
    var sum=0
        cy.totalOfEachProductsAddedToCart(sum)
        cy.totalOfAllProductsAddedToCart(sum)

})

Then('select the country submit and verify Success', function()
{
    checkoutPage.getCheckoutButton().click()
        // select India from delivery location dynamic dropdown
        purchasePage.getDeliveryLocationDropdown().type('ind')
        cy.wait(8000)
        cy.selectCountryFromList(this.data.countryname)
        ///assertion to check if India is selected from the dropdown
        purchasePage.getDeliveryLocationDropdown().should('have.value',this.data.countryname)
        //agree to terms checkbox & validating if checked
        purchasePage.getAgreeToTermsCheckbox().check({force:true}).should('be.checked')
        //clicking on Purchase Button
        purchasePage.getPurchaseButton().click()
        //validate if clicking on Purchase Button a succesful purchased mesage appears
        purchasePage.getSuccessfulPurchasedMessage().then(function(element)
        {
            const successMsg=element.text()
            //assertion to expect true
            expect(successMsg.includes('Success')).to.be.true
        })
})

        When('I fill the form details', function(dataTable)
        {
            // using cucumber feature feature file to get the details not frm fixtures
            name=dataTable.rawTable[1][0]
            homePage.getNameEditBox().type(dataTable.rawTable[1][0]) //treating dataTable as 2D array
            homePage.getEmailEditBox().type(dataTable.rawTable[1][1])
            //Entering password in text box
            homePage.getPasswordEditBox().type(dataTable.rawTable[1][2])
            //Selecting female from Gender static dropdown
            homePage.getGenderDropdown().select(dataTable.rawTable[1][3])

        })
        Then('Validate the form behaviour', function()
        {
            homePage.getTwoWayDataBindingEditBox().should('have.value',name) //jquery
            //verify if minlength of name text box is 2 or not
            homePage.getNameEditBox().should('have.attr','minlength','2')//any attribute checking, can go on like this
            homePage.getLoveIcecreamCheckbox().check().should('be.checked')
            homePage.getEntrepreneurRadioButton().should('be.disabled')

        })

        And('select the shop page', function()
        {
            homePage.getShopTab().click()

        })


