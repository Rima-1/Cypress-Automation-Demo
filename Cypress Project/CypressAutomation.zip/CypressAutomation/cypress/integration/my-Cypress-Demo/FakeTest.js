/// <reference types="Cypress"/>

describe('My First Test Suite', function() {

    //In here we are actually trying to modify/mock a reponse(it's in JSON format) shown in front-end in form of a table
    //Like mocking the body actually of that json reponse to get only 1 result out of that table, not all of the responses
    // Here the scenario is, in this table(or this library) many books can be added in future, and when that book isn't in library,
    //this website will not display that book. So, the performance of this particular page is dynamic.
    // But, our requirement is to verify a message "...." when only 1 book is available here.
    // This case is normally impossible to automate with Selenium but, Cypress can.

    it('Navigating to url', function() {
        //hitting the URL
        cy.visit("https://rahulshettyacademy.com/angularAppdemo/")
    })

    it('Mocking response', function() {

        //mocking our response using cy.intercept()
        //cy.intercept({requestObject}, {responseObject})
        cy.intercept({
            method : 'GET',
            url : 'https://rahulshettyacademy.com/Library/GetBook.php?AuthorName=shetty'
            //cypress willn't make this call, it will only listen(or keep an eye) to the call made on browser
            //once this call is made on browser, cypress will ask you, I just came to know, that this call is made
            // and let me know, if I need to send the real response or do you want to mock it & send your own response
        },
        //In this case we want to mock it
        {
            statusCode : 200,
            //body is what we want to mock
            //body : [{"book_name":"RestAssured with Java","isbn":"RSU","aisle":"2301"},{"book_name":"RestAssured with Java","isbn":"RSU","aisle":"2301"}]
            body : [{"book_name":"RestAssured with Java","isbn":"RSU","aisle":"2301"}]
        }).as('bookretrievals')

        //goto Virtual Library
        cy.get('.btn.btn-primary').click()
        //we have to wait until cypress intercepted that response
        cy.wait('@bookretrievals').should(({request, response}) =>
        {
            //validating 2nd scenario for mocked response
            //in here it's validating the length of <tr> s (the locator of the table we got from site) with length of mock response of body
            //response.body.length+1 is done coz we have another <tr> for the row containing bookname, etc......
            cy.get('tr').should('have.length',response.body.length+1)
            //magic is that even if we give two responses in the body above, this validating line still remains same.
        })
        //validating if only 1 response is present
        cy.get('p').should('have.text','Oops only 1 Book available')
    })

    //2nd Scenario : Integration Testing between UI and backend
    //we need to validate the response coming from API calls in POSTMAN is actually matching in UI
    //to get response of API calls u also can (inspect->network tab->click on APIlink -> popup in RHS -> Response tab-> get ur JSON response)
    //here actually we need to compare API response & what are seeing in UI
    //Cypress have access in network level, so it's possible
    //as this is a dynamic case, like today we hv 50 records tomorrow it may be 60. So, we needto verify (may it be for mocked/actual response)
    //length of the response array = rows of the table


    
    
})