/// <reference types="Cypress"/>


//3rd Scenario : modify/mock an HTTP request's body, headers & URL before it's sent to destination server
//when we select this library everytime in site, in request url 'AuthorName=shetty' is found
//let's say you are only authorized to see Shetty author's library but not Malhotra's from your portal
//and when u try to view that, then you should get 403 ('forbidden') status response code
//that is what u want to test & make sure data shouldn't display

describe('My First Test Suite', function() {

    it('Navigating to url', function() {
        //hitting the URL
        cy.visit("https://rahulshettyacademy.com/angularAppdemo/")
      
    })

    it('Mocking request', function() {
        //cy.intercept(method, url, routeHandler)
        cy.intercept('GET', 'https://rahulshettyacademy.com/Library/GetBook.php?AuthorName=shetty',
        (req)=>
        {
            // To modify url
            req.url="https://rahulshettyacademy.com/Library/GetBook.php?AuthorName=malhotra"
            //when we call this continue() then this request is being sent to the server
            //once we send this to the server we get response back, that response is collected as reference variable here in response object
            req.continue((res)=> //and on this response object you can put any validation
            {
                //validating if status code of this response is 403
                //expect(res.statusCode).to.equal(403)
                //now we should get this validation error, coz no security is applied & status code must be 200
                //Also security testing is done here, if statuscode=200, that's a security bug

            })
        }).as("dummyURL")
        //goto Virtual Library
        cy.get('.btn.btn-primary').click()
        cy.wait('@dummyURL')

        

    })
})