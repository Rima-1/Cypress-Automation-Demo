/// <reference types="Cypress"/>

describe('JWT Session Token Test', function() 
{

    it('is logged in through browser local storage', function() {

        cy.LoginAPI().then(function()
        {
            //if we haven't logged in this following url will actually take you to the login page
            //but, here calling that LoginAPI() we are smartly telling that, before you visit this URL, go and set the token in the local storage.
            //this browser local storage is actually --> in browser inspect & open the application tab, u can find local storage
            //give this knowledge to get() by setting options as 2nd args
            cy.visit("https://rahulshettyacademy.com/client", 
            {
                //onBeforeLoad is the event which will occur before hitting the above url
                onBeforeLoad :function(window) //javascript function
                {
                    window.localStorage.setItem('token', Cypress.env('token'))
                }

            })
            //no login screen, bypassed that, now enjoy !!!!
        })
      
    })

    /*it('End to end workflow', function() {//not working
        //2nd product add to cart
        cy.get(".card-body button:last-of-type").eq(1).click({force:true})
        cy.wait(8000)
        //cy.get(':nth-child(2) > .card > .card-body > .w-10').click()
        //click on cart tab to go to cart page
        cy.get('[routerlink*="cart"]').click({force: true})
        //click on Checkout to land on product review page
        cy.contains('Checkout').click()
        cy.get('[placeholder*="Country"]').type('ind')
        cy.get('.ta-results button').each(($el, index, $list) =>
        {
            if($el.text()==="India")
            {
                cy.wrap($el).click();
            }

        })
        //assertion to check if India is selected from the dropdown
        cy.get('[placeholder*="Country"]').should('have.value','India')
        //click on checkout button
        cy.get('.action__submit').click()
        //wait 2 sec. to get csv to download
        cy.wait(2000)
        //button click to download CSV
        cy.get('.order-summary button').click()
      
    })*/
})