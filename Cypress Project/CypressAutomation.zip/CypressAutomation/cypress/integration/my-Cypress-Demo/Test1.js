/// <reference types="Cypress"/>

//describe is test suite, and multiple test cases can be there in it.

//it block is treated as test case
//automation test code which you feel needed to test put it inside one it block

describe('My First Test Suite', function() {

    it('Navigating to url', function() {
        //hitting the URL
        cy.visit("https://rahulshettyacademy.com/seleniumPractise/#/");
      //expect(true).to.equal(true)
      
    })

    it('search something and verify methods', function() {
        //get acts like findelement of Selenium
      cy.get('.search-keyword').type('ca');
      cy.wait(2000);
      // should() is from chai lib. for assertion
      // expecting the no of products is 4
      //cy.get('.product').should('have.length',4);
      //assertion fails -- one or more elements is not visible to us (cypress told)
      cy.get('.product:visible').should('have.length',4); //to get visible products only
      //here find() gets the child elements of a selector mentioned
      cy.get('.products').find('.product').should('have.length',4);
    })

    it('add to cart', function() {
        //eq() is to pass index to select which addtocart button needed to click
        //contains() search for that specific text
        cy.get('.products').find('.product').eq(2).contains('ADD TO CART').click();
        //check the text if "cashews" then click on add tocart
        //each() to iterate array
        cy.get('.products').find('.product').each(($el, index, $list) =>
        {
            const textveg = $el.find('h4.product-name').text();
            if(textveg.includes('Cashews'))
            {
                cy.wrap($el).find('button').click();
                
            }
        })
        
    })

    it('logo test in log', function() {

        //assert if the value got from logo matches with actual value
        cy.get('.brand').should('have.text','GREENKART');

       // const logo=cy.get('.brand')
        //cy.log(logo.text()) -- logo.text is not a function, error -- throwing into a variable non-cypress things come here
        // so, handle it manually //text() is a jquery method, not a cypress command, but, cypress supports it
        cy.get('.brand').then(function(logo)
        {
            cy.log(logo.text())
            

        })

        //cy.log(cy.get('.brand').text()) -- cy.get(....).text is not a function
       
        
    })

    it('place order and checkout', function() {

        //click on bag
        cy.get('.cart-icon > img').click()
        cy.contains('PROCEED TO CHECKOUT').click()
        //place order button click and land on checkout page
        cy.contains('Place Order').click()
        //click on dropdown and select a value & validate it
        cy.get('select').select('India').should('have.value','India')
        //click on agree checkbox & validate it
        cy.get('.chkAgree').check().should('be.checked')
        //click on Proceed button
        cy.contains('Proceed').click()
    })

   // it('My second test case', function() {
     //   expect(true).to.equal(true)
     // })

  })