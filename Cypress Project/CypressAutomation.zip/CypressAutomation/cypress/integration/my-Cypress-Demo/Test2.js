/// <reference types="Cypress"/>
/// <reference types="cypress-iframe"/>
import 'cypress-iframe'

describe('My Second Test Suite', function() {

    it('Navigating to url', function() {
        //hitting the URL
        cy.visit("https://rahulshettyacademy.com/AutomationPractice/")
        //cy.visit("https://automationteststore.com/")
      //expect(true).to.equal(true)
      
    })

    it('Checkboxes Example', function() {
        // Click on 1st checkbox & verify if checked or not & verify if option1 value checkbox is checked
        //for concatenation of assertions, use and(), it takes automatically as should()
        //for comparing a value -- 'have.' & an actual value, & for comparing a behaviour -- 'be.' iny our assertions
        cy.get('#checkBoxOption1').check().and('have.value','option1')
        // uncheck 1st checkbox & verify if unchecked or not
        cy.get('#checkBoxOption1').uncheck().should('not.be.checked')
        // Click on all checkboxes at once & verify if checked or not only specified elements value
        cy.get('input[type="checkbox"]').check(['option2','option3']).should('be.checked')
        
    })

    it('Dropdowns Example', function() {
        //static dropdown where value is fixed
        //click on dropdown and select a value & validate it
        cy.get('select').select('option2').should('have.value','option2')
        //dynamic dropdown where value is typed to get value from dropdown list to click it
        cy.get('#autocomplete').type('ind')
        cy.get('.ui-menu-item div').each(($el, index, $list) =>
        {
            if($el.text()==="India")
            {
                cy.wrap($el).click();
            }

        })
        //assertion to check if India is selected from the dropdown
        cy.get('#autocomplete').should('have.value','India')
        
    })

    it('Visible & Invisible Elements Example', function() {
        //verify if edit box is visible or not
        cy.get('#displayed-text').should('be.visible')
        //select hide button
        cy.get('#hide-textbox').click()
        //verify if edit box is invisible or not
        cy.get('#displayed-text').should('not.be.visible')
        //select show button
        cy.get('#show-textbox').click()
        //verify if edit box is visible or not
        cy.get('#displayed-text').should('be.visible')
    })

    it('Radio Button Example', function() {
        // Click on 2nd Radio Button & verify if checked or not & verify if radio2 value Radio Button is checked
        cy.get('[value="radio2"]').check().should('be.checked').and('have.value','radio2')
        
    })

    it('Switch To Alert Example', function() {
        //cypress auto accepts alert
        cy.get('#alertbtn').click() // only ok button present, accepts it
        cy.get('[value="Confirm"]').click() // both ok & cancelbutton present in alert, auto accept ok
        //verify text present in alert
        //event ---> window:alert // trigger this event by cypress by using on()
        cy.on('window:alert',(str) =>
        {
            //comparing 2 strings in mocha
            expect(str).to.equal('Hello , share this practice page and share your knowledge')
        })
        //event ---> window:confirm // trigger this event by cypress by using on()
        cy.on('window:confirm',(str) =>
        {
            expect(str).to.equal('Hello , Are you sure you want to confirm?')
        })
    })

    it('Switch Tab Example', function() {
        //how to handle child tab
        //cypress can't handle child tab, so need to manipulate code to open the child tab in same tab, which cypress can handle
        //it basically needs to remove the target attribute in html code
        //removeattr() method of jquery can remove attribute & need to invoke by cypress using invoke(functionname, name of attr to remove)
        cy.get('#opentab').invoke('removeAttr','target').click()
        //verify if landed on child page
        cy.url().should('include','rahulshettyacademy')
        //come to original page by using browser navigation method using cypress go('back') or to move forward by go('forward')
        cy.go('back')
            
    })

    it('Web Table Example', function() {
        //validate a price for a course in the table
        cy.get('tr td:nth-child(2)').each(($el, index, $list) =>
        {
            const text=$el.text()
            if(text.includes('Python'))
            {
                //how to move to its next sibling to get its price
                cy.get('tr td:nth-child(2)').eq(index).next().then(function(price)
                {
                    const priceText=price.text()
                    expect(priceText).to.equal('25')
                })
            }

        })
            
    })

    it('Mouse Hover Example', function() {
        //Actions class used in selenium, but cypress don't directly support mouse hover
        //Jquery show method is used to display hidden & selected elements under the mouse hovered button, so invoke show
        cy.get('.mouse-hover-content').invoke('show')
        cy.contains('Top').click()
        //{force:true} of cypress checks the hidden/invisible element & can forcibly click on it
        //cy.contains('Top').click({force:true})
        //validate if url changes on clicking this
        cy.url().should('include','top')
        
            
    })

    it('Handle frame Example', function() {
        //how to handle i-frame
        // firstly go into a new terminal & run cmmnd => npm install -D cypress-iframe
        // Then, import 'cypress-iframe'
        // need to know frame id first
        cy.frameLoaded('#courses-iframe')
        //hey, cypress, switch to iframe mode
        cy.iframe().find("a[href*='mentorship']").eq(0).click()
        //cy.get('#courses-iframe',{timeout:10000}).iframe("h1[class*='pricing-title']").should('exist')//tried by myself//same error
        cy.iframe().find("h1[class*='pricing-title']").should('have.length','2')//getting error//need help
         
            
    })

    
})