/// <reference types="Cypress"/>

//using PageObjectModel
import HomePage from '../../support/Page-Objects/HomePage'
import ShopPage from '../../support/Page-Objects/ShopPage'
import CheckoutPage from '../../support/Page-Objects/CheckoutPage'
import PurchasePage from '../../support/Page-Objects/PurchasePage'


describe('Async hooks', function() 
{
//need to keep before block before describe block because of mocha framework setup
before(function(){
    // runs once before all tests in the block
    //to get value from fixture
    cy.fixture('example.json').then(function(data)
    {
        //we need to access this data variable from other functions, but it's restricted to this block
        //if you point any variable with 'this.data'(like this eg.).
        //this keyword refers to whole class
        this.data=data
    })
})


describe('My First Test Suite', function() 
{
    const homePage=new HomePage()
    const shopPage=new ShopPage()
    const checkoutPage=new CheckoutPage()
    const purchasePage=new PurchasePage()

    it('Navigating to url', function() {
        //hitting the URL
        //to make the url global variable, 1st go to cypress.json to declare env
        cy.visit(Cypress.env('url')); //now do this to hit url
        //cy.visit(Cypress.env('url')+"/AutomationPractise"); where url : https://rahulshettyacademy.com
      
    })

    it('Entering name', function() {
        
        //Taking hard coated data from fixtures
        //Entering name in text box
        
        homePage.getNameEditBox().type(this.data.myname)
        //verify two way-data binding of angular.
        //if we enter name in 1st text box, watch in last text box, if the same name appears by default
        homePage.getTwoWayDataBindingEditBox().should('have.value',this.data.myname) //jquery
        //verify if minlength of name text box is 2 or not
        homePage.getNameEditBox().should('have.attr','minlength','2')//any attribute checking, can go on like this
    })

    it('Entering details', function() {
        //Taking hard coated data from fixtures
        //Entering email in text box
        homePage.getEmailEditBox().type(this.data.myemail)
        //Entering password in text box
        homePage.getPasswordEditBox().type(this.data.mypassword)
        //Selecting female from Gender static dropdown
        homePage.getGenderDropdown().select(this.data.mygender)
        //Checking the checkbox "Check me out if you Love IceCreams!" & validate if checked
        homePage.getLoveIcecreamCheckbox().check().should('be.checked')
      
    })
    it('Employment status', function() {
        //validate if entrepreneur radiobutton is disabled or not
        homePage.getEntrepreneurRadioButton().should('be.disabled')
    })

    it('Exploring shop & checkout page', function() {
        //clicking on shop button and a new page opens
        homePage.getShopTab().click()
        //getting a common locator to track all the phones to iterate through the list
        //using phone names from example.json of fixtures folder
        const phoneListLocator=this.data.phoneArrayLocator
        this.data.phonenames.forEach(function(element) 
        {
            //using custom command of cypress from commands.js of support folder
            cy.selectProductFromList(element, phoneListLocator)
        })
        //Click on checkout button on shop page to land on checkout page
        shopPage.getCheckoutButton().click()
        ///validate the total amount(in rs.) of no. of products present on checkout page now dynamically if correct
        var sum=0
        cy.totalOfEachProductsAddedToCart(sum)
        cy.totalOfAllProductsAddedToCart(sum)
    })

    it('Exploring Purchase page', function() {
        //click on checkout button on checkout page to land on purchase page
        checkoutPage.getCheckoutButton().click()
        // select India from delivery location dynamic dropdown
        purchasePage.getDeliveryLocationDropdown().type('ind')
        cy.wait(8000)
        cy.selectCountryFromList(this.data.countryname)
        ///assertion to check if India is selected from the dropdown
        purchasePage.getDeliveryLocationDropdown().should('have.value',this.data.countryname)
        //agree to terms checkbox & validating if checked
        purchasePage.getAgreeToTermsCheckbox().check({force:true}).should('be.checked')
        //clicking on Purchase Button
        purchasePage.getPurchaseButton().click()
        //validate if clicking on Purchase Button a succesful purchased mesage appears
        purchasePage.getSuccessfulPurchasedMessage().then(function(element)
        {
            const successMsg=element.text()
            //assertion to expect true
            expect(successMsg.includes('Success')).to.be.true
        })
        
    })

    
})
})
