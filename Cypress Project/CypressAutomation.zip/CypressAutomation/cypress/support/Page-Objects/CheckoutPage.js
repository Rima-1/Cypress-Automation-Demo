class CheckoutPage
{

    getCheckoutButton()
    {
        return cy.contains('Checkout')
    }

    getTotalofEachProductAddedToCart()
    {
        return cy.get('tr td:nth-child(4) strong')
    }
    
    getTotalofAllProductsAddedToCart()
    {
        return cy.get('h3 strong')
    }

}

export default CheckoutPage;