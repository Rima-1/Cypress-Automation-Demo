class HomePage
{
    getNameEditBox()
    {
        return cy.get('input[name="name"]:nth-child(2)')
    }

    getTwoWayDataBindingEditBox()
    {
        return cy.get('input[name="name"]:nth-child(1)')
    }

    getEmailEditBox()
    {
        return cy.get('input[name="email"]')
    }

    getPasswordEditBox()
    {
        return cy.get('#exampleInputPassword1')
    }

    getGenderDropdown()
    {
        return cy.get('#exampleFormControlSelect1')
    }

    getLoveIcecreamCheckbox()
    {
        return cy.get('#exampleCheck1')
    }

    getEntrepreneurRadioButton()
    {
        return cy.get('#inlineRadio3')
    }

    getShopTab()
    {
        return cy.contains('Shop')
    }
}

//if you use export keyword here, javascript will make sure to make this class available to all other files in your frameworks
export default HomePage;