class PurchasePage
{
    getDeliveryLocationDropdown()
    {
        return cy.get('#country')
    }

    getSuggestionfromDeliveryLocationDropdown()
    {
        return cy.get('.suggestions ul li a')
    }

    getAgreeToTermsCheckbox()
    {
        return cy.get('#checkbox2')
    }

    getPurchaseButton()
    {
        return cy.get('input[type="submit"]')
    }

    getSuccessfulPurchasedMessage()
    {
        return cy.get('.alert')
    }

}

export default PurchasePage;