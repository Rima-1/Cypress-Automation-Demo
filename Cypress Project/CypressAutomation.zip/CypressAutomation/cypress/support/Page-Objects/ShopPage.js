class ShopPage
{
    getPhoneArrayLocator(locator)
    {
        return cy.get(locator)
    }

    getAddToCartButton()
    {
        return cy.get('button.btn.btn-info')
    }

    getCheckoutButton()
    {
        return cy.contains('Checkout')
    }
}

export default ShopPage;