// ***********************************************
// This example commands.js shows you how to
// create various custom commands and overwrite
// existing commands.
//
// For more comprehensive examples of custom
// commands please read more here:
// https://on.cypress.io/custom-commands
// ***********************************************
//
//
// -- This is a parent command --
// Cypress.Commands.add('login', (email, password) => { ... })
import ShopPage from '../support/Page-Objects/ShopPage'
import PurchasePage from '../support/Page-Objects/PurchasePage'
import CheckoutPage from '../support/Page-Objects/CheckoutPage'

Cypress.Commands.add('selectProductFromList', (productName, locator) => {
const shopPage=new ShopPage()
shopPage.getPhoneArrayLocator(locator).each(($el, index, $list) =>
{
    //checking here if got our required phone name from that list
    if($el.text().includes(productName))
    {
        //add to cart button click
        shopPage.getAddToCartButton().eq(index).click()
    }
})
})

Cypress.Commands.add('selectCountryFromList', (location) => {
    const purchasePage=new PurchasePage()
    purchasePage.getSuggestionfromDeliveryLocationDropdown().each(($el, index, $list) =>
    {
        if($el.text()===location)
        {
            cy.wrap($el).click();
        }

    })
    })

    const checkoutPage=new CheckoutPage()
    var actualsum=0
    Cypress.Commands.add('totalOfEachProductsAddedToCart', (sum) => {

        checkoutPage.getTotalofEachProductAddedToCart().each(($el, index, $list) =>
        {
            //cy.log($el.text()) // we are getting 'rs. ' concatenated with our amt. so need to remove that
            //using split() will cut the string before and after space
            const amount=$el.text()
            var result=amount.split(" ")
            result=result[1].trim()
            //cy.log(result)
            
            actualsum= Number(actualsum)+Number(result)
    
        }).then(function(element){
            cy.log(actualsum)
        })
            
        
        })

        Cypress.Commands.add('totalOfAllProductsAddedToCart', (sum) => {
            
            checkoutPage.getTotalofAllProductsAddedToCart().then(function(element)
        {
            //cy.log($el.text()) // we are getting 'rs. ' concatenated with our amt. so need to remove that
            //using split() will cut the string before and after space
            const totalAmount=element.text()
            var resAmt=totalAmount.split(" ")
            resAmt=resAmt[1].trim()
            //cy.log(resAmt)
            expect(Number(resAmt)).to.equal(actualsum)
    
        })
        
        })

    
    Cypress.Commands.add('LoginAPI',()=>{
        //cy.request(requestMethod,requestURL,payload)// go to network tab to find them(headers & payload)
        cy.request("POST","https://rahulshettyacademy.com/api/ecom/auth/login",
        {"userEmail": "LittleSquid1999@gmail.com", "userPassword": "Squiddy@1999"}).
        then(function(response){
            expect(response.status).to.eq(200)
            //we are creating an environment var. token to make it available everywhere in ur framework, & response.body.token is the value of token got from site
            Cypress.env('token', response.body.token);
        })
    })
//
//
// -- This is a child command --
// Cypress.Commands.add('drag', { prevSubject: 'element'}, (subject, options) => { ... })
//
//
// -- This is a dual command --
// Cypress.Commands.add('dismiss', { prevSubject: 'optional'}, (subject, options) => { ... })
//
//
// -- This will overwrite an existing command --
// Cypress.Commands.overwrite('visit', (originalFn, url, options) => { ... })
